import { Text } from 'react-native';
import EstiloRodape from '../styles/EstiloRodape';

export default () => (
        <>
            <Text style={EstiloRodape.rodape}>Rodapé</Text>
        </>
)
