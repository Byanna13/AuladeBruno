import { Text } from 'react-native';

export default () => (
        <>
            <Text>Menu</Text>
        </>
)
